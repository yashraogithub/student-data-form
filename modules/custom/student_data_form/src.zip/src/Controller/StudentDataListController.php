<?php

namespace Drupal\student_data_form\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Database;
use Drupal\Core\Url;
use Drupal\Core\Link;

class StudentDataListController extends ControllerBase {

  public function studentList() {
    $header = [
      'id' => $this->t('ID'),
      'name' => $this->t('Name'),
      'class' => $this->t('Class'),
      'section' => $this->t('Section'),
      'contact' => $this->t('Contact'),
      'address' => $this->t('Address'),
      'operations' => $this->t('Operations'),
    ];

    $rows = [];
    $conn = Database::getConnection();
    $results = $conn->select('student_data', 's')
      ->fields('s', ['id', 'student_name', 'student_class', 'student_section', 'student_contact', 'student_address'])
      ->execute();

    foreach ($results as $record) {
      // Create Edit and Delete URLs
      $edit_url = Url::fromRoute('student_data_form.edit', ['id' => $record->id]);
      $delete_url = Url::fromRoute('student_data_form.delete', ['id' => $record->id]);

      $operations = [
        Link::fromTextAndUrl('Edit', $edit_url)->toString(),
        Link::fromTextAndUrl('Delete', $delete_url)->toString(),
      ];

      $rows[] = [
        'id' => $record->id,
        'name' => $record->student_name,
        'class' => $record->student_class,
        'section' => $record->student_section,
        'contact' => $record->student_contact,
        'address' => $record->student_address,
        'operations' => [
          'data' => [
            '#markup' => implode(' | ', $operations),
          ]
        ],
      ];
    }

    return [
      '#type' => 'table',
      '#header' => $header,
      '#rows' => $rows,
      '#empty' => $this->t('No student records found.'),
    ];
  }
}
